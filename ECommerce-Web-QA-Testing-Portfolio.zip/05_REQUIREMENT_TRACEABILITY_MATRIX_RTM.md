# 📊 Requirement Traceability Matrix (RTM) — E-Commerce Application

**Author:** Sher Ali (QA Engineer)  
**Objective:** Ensure 100% test coverage by bidirectional mapping from Business Requirements to Test Cases and Defect IDs.  

---

| Requirement ID | Business Requirement Description | Test Scenario ID | Test Case ID | Test Execution Status | Defects Logged |
| :--- | :--- | :--- | :--- | :---: | :---: |
| **REQ-AUTH-01** | User must be able to register with unique email and secure password | TS-AUTH-01 | TC-AUTH-01, TC-AUTH-02 | **PASS** | None |
| **REQ-AUTH-02** | User must be able to log in and toggle password visibility | TS-AUTH-03 | TC-AUTH-03, TC-AUTH-04, TC-AUTH-05 | **PASS** | None |
| **REQ-CAT-01** | User must be able to search and filter products by price and category | TS-CAT-01, TS-CAT-02 | TC-CAT-01, TC-CAT-02, TC-CAT-03 | **PASS** | None |
| **REQ-CAT-02** | Product sorting must accurately order catalog items | TS-CAT-03 | TC-CAT-04 | **FAIL** | **BUG-001** |
| **REQ-CART-01**| Cart must prevent ordering items exceeding warehouse stock | TS-CART-03 | TC-CRT-01, TC-CRT-02, TC-CRT-03 | **FAIL** | **BUG-002** |
| **REQ-CART-02**| System must validate coupon codes and prevent duplicate discounts | TS-CART-05, TS-CART-06 | TC-CRT-04, TC-CRT-05 | **FAIL** | **BUG-004** |
| **REQ-CHK-01** | Checkout must enforce mandatory shipping address fields | TS-CHK-02 | TC-CHK-01 | **PASS** | None |
| **REQ-CHK-02** | Payment gateway must validate credit card formats before submission | TS-CHK-04 | TC-CHK-02 | **FAIL** | **BUG-003** |
| **REQ-ORD-01** | Successful order must decrement stock in database and send receipt | TS-CHK-05, TS-CHK-06 | TC-CHK-03, TC-CHK-04 | **PASS** | None |
| **REQ-UI-01**  | Mobile viewport must display buttons clearly without overlapping | TS-CART-01 | TC-CRT-06 | **FAIL** | **BUG-005** |

---

### 📈 Traceability Summary:
- **Total Requirements:** 10
- **Requirements Covered by Tests:** 10 (100% Coverage)
- **Passing Requirements:** 6
- **Requirements with Open Defects:** 4
