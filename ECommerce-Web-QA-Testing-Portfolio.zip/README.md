<div align="center">

  <h1>🛒 E-Commerce Web Application — End-to-End QA Testing Portfolio</h1>
  <p><b>Comprehensive Manual Testing Documentation: Test Plan, Test Cases, Bug Reports, RTM & SQL Verification</b></p>

  <p align="center">
    <img src="https://img.shields.io/badge/Testing_Type-Manual_&_Functional-008080?style=for-the-badge&logo=checkmarx&logoColor=white" />
    <img src="https://img.shields.io/badge/Test_Cases-35+_Documented-0E75B6?style=for-the-badge" />
    <img src="https://img.shields.io/badge/Bugs_Logged-5_Real_Defects-DC2626?style=for-the-badge" />
    <img src="https://img.shields.io/badge/SQL_Validation-CRUD_&_Orders-336791?style=for-the-badge&logo=postgresql&logoColor=white" />
  </p>

  <p align="center">
    <a href="https://www.linkedin.com/in/sher-ali-b07457347" target="_blank">
      <img src="https://img.shields.io/badge/QA_Tester-Sher_Ali-0A66C2?style=flat-square&logo=linkedin&logoColor=white" alt="LinkedIn" />
    </a>
    &nbsp;
    <a href="mailto:s38454672@gmail.com">
      <img src="https://img.shields.io/badge/Email-s38454672%40gmail.com-D14836?style=flat-square&logo=gmail&logoColor=white" alt="Email" />
    </a>
  </p>

</div>

---

## 📌 Project Overview

This repository represents the **core bread-and-butter testing portfolio** expected of every professional Software Quality Assurance Engineer. It contains complete, production-ready QA artifacts for an **E-Commerce Web Application** (covering User Authentication, Product Search & Catalog, Shopping Cart, Discounts, Checkout, and Database Verification).

---

## 📑 Portfolio Contents & QA Deliverables

| File | Document | Description |
| :--- | :--- | :--- |
| 📋 **[`01_TEST_PLAN.md`](./01_TEST_PLAN.md)** | **Master Test Plan** | Scope, strategy, test environment, entry/exit criteria, and risks. |
| 🔍 **[`02_TEST_SCENARIOS.md`](./02_TEST_SCENARIOS.md)** | **Test Scenarios** | High-level business flows and user journeys across all modules. |
| 🧪 **[`03_DETAILED_TEST_CASES.md`](./03_DETAILED_TEST_CASES.md)** | **Test Cases Suite** | 35+ granular test cases with steps, test data, expected vs actual results. |
| 🐞 **[`04_BUG_REPORTS_DEFECT_LOG.md`](./04_BUG_REPORTS_DEFECT_LOG.md)** | **Defect Reports Log** | 5 detailed Jira-standard bug tickets with severity, priority, and steps. |
| 📊 **[`05_REQUIREMENT_TRACEABILITY_MATRIX_RTM.md`](./05_REQUIREMENT_TRACEABILITY_MATRIX_RTM.md)** | **RTM Matrix** | 100% test coverage verification mapping Requirements ➔ Test Cases ➔ Defects. |
| 🗄️ **[`06_SQL_DATABASE_VALIDATION_QUERIES.sql`](./06_SQL_DATABASE_VALIDATION_QUERIES.sql)** | **Database Verification** | SQL queries for verifying user registration, order creation, and stock updates. |
| 📈 **[`07_TEST_EXECUTION_SUMMARY_REPORT.md`](./07_TEST_EXECUTION_SUMMARY_REPORT.md)** | **Execution Summary** | Test metrics, pass/fail percentages, and release recommendation sign-off. |

---

## 🛠️ Testing Methodologies & Techniques Applied

- **Black Box Testing:** Functional, UI, Regression, Smoke, Sanity, Exploratory.
- **Test Design Techniques:** Boundary Value Analysis (BVA), Equivalence Class Partitioning (ECP).
- **Database Testing:** SQL queries for backend data validation.
- **Cross-Browser Testing:** Google Chrome, Mozilla Firefox, Microsoft Edge.

---

## 📊 Quick Execution Summary

```
Total Test Cases Executed : 35
✅ Passed                 : 30 (85.7%)
❌ Failed (Defects Logged): 5  (14.3%)
Execution Status          : Completed
Defects Severity Breakdown: 1 Critical (S1), 2 Major (S2), 2 Minor (S3)
```

---

## 👨‍💻 QA Engineer Contact

**Sher Ali**  
*Software QA Engineer*  
- 💼 **LinkedIn:** [sher-ali-b07457347](https://www.linkedin.com/in/sher-ali-b07457347)  
- 📧 **Email:** [s38454672@gmail.com](mailto:s38454672@gmail.com)  
- 🌐 **GitHub:** [@SherAli45](https://github.com/SherAli45)  
