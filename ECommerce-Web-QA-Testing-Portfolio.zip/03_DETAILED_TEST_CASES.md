# 🧪 Detailed Test Cases — E-Commerce Web Application

**Author:** Sher Ali (QA Engineer)  

---

## 🔐 Module: Authentication & User Registration

| TC ID | Title | Pre-Conditions | Test Steps | Test Data | Expected Result | Actual Result | Status | Priority |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :---: | :---: |
| **TC-AUTH-01** | Successful User Registration | User is on Signup page | 1. Enter valid Full Name<br>2. Enter valid unused Email<br>3. Enter valid password (8+ chars, 1 number, 1 special char)<br>4. Click 'Register' | Name: Ali Khan<br>Email: ali.test@example.com<br>Pass: Pass@1234 | Account created, verification email sent, redirected to Dashboard. | As expected. | **PASS** | **P0** |
| **TC-AUTH-02** | Registration with Duplicate Email | User is on Signup page | 1. Enter already registered email<br>2. Fill other fields<br>3. Click 'Register' | Email: ali.test@example.com | Error message displayed: "Email already registered. Please log in." | As expected. | **PASS** | **P1** |
| **TC-AUTH-03** | Password Masking & Visibility Toggle | User is on Login page | 1. Enter password<br>2. Verify bullet masking<br>3. Click eye icon to reveal | Pass: Secret123 | Password shows bullets initially, unmasks to plaintext on eye click. | As expected. | **PASS** | **P2** |
| **TC-AUTH-04** | Login with Valid Credentials | Active user exists | 1. Navigate to `/login`<br>2. Enter valid Email & Password<br>3. Click 'Sign In' | Email: ali.test@example.com<br>Pass: Pass@1234 | User logged in, redirected to homepage, username displayed in header. | As expected. | **PASS** | **P0** |
| **TC-AUTH-05** | Login with Incorrect Password | User is on Login page | 1. Enter valid Email<br>2. Enter wrong Password<br>3. Click 'Sign In' | Pass: WrongPass99 | Error: "Invalid email or password". Password field cleared. | As expected. | **PASS** | **P0** |

---

## 🔎 Module: Product Catalog & Search

| TC ID | Title | Pre-Conditions | Test Steps | Test Data | Expected Result | Actual Result | Status | Priority |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :---: | :---: |
| **TC-CAT-01** | Search Product by Exact Name | User on Homepage | 1. Enter exact product name in search bar<br>2. Click Search button | Query: "Wireless Noise Cancelling Headphones" | Search results page displays the exact matching product. | As expected. | **PASS** | **P0** |
| **TC-CAT-02** | Search with Special Characters / SQL Injection | User on Homepage | 1. Enter `' OR '1'='1` in search<br>2. Press Enter | Query: `' OR '1'='1` | Sanitized input, displays "No products found for your query". No SQL error. | As expected. | **PASS** | **P1** |
| **TC-CAT-03** | Filter Products by Price Range | User on Catalog page | 1. Set Min Price = $50, Max Price = $100<br>2. Click Apply Filter | Min: $50, Max: $100 | Only products with prices between $50.00 and $100.00 are shown. | As expected. | **PASS** | **P1** |
| **TC-CAT-04** | Sort Products by Price: High to Low | User on Catalog page | 1. Click Sort dropdown<br>2. Select "Price: High to Low" | Sort: High to Low | Products reordered with highest price at top descending down. | Products sorted, but some $0.00 items appear at top! | **FAIL** (BUG-01) | **P1** |

---

## 🛒 Module: Shopping Cart & Discounts

| TC ID | Title | Pre-Conditions | Test Steps | Test Data | Expected Result | Actual Result | Status | Priority |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :---: | :---: |
| **TC-CRT-01** | Add In-Stock Product to Cart | Product has 10 units in stock | 1. On product page, click 'Add to Cart'<br>2. Observe cart badge icon | Qty: 1 | Toast message: "Item added to cart". Cart badge increments by 1. | As expected. | **PASS** | **P0** |
| **TC-CRT-02** | Add Out-of-Stock Product to Cart | Product has 0 units in stock | 1. View product with 0 stock<br>2. Check 'Add to Cart' button | Stock: 0 | Button is disabled with label "Out of Stock". Cannot add to cart. | As expected. | **PASS** | **P0** |
| **TC-CRT-03** | Update Cart Quantity Exceeding Available Stock | 5 units in stock | 1. In cart, enter 10 in quantity box<br>2. Click Update | Available: 5, Requested: 10 | Error: "Cannot order more than 5 available units". Qty reset to 5. | Cart allows entering 10 and checkout proceeds! | **FAIL** (BUG-02) | **P0** |
| **TC-CRT-04** | Apply Valid Discount Promo Code | Cart subtotal = $100.00 | 1. Enter promo code "SAVE20"<br>2. Click 'Apply' | Code: SAVE20 (20% off) | Discount of $20.00 subtracted. New subtotal = $80.00 + tax. | As expected. | **PASS** | **P1** |
| **TC-CRT-05** | Apply Expired Promo Code | Cart subtotal = $100.00 | 1. Enter expired code "SUMMER2022"<br>2. Click 'Apply' | Code: SUMMER2022 | Error: "Coupon code has expired". Total unchanged. | As expected. | **PASS** | **P2** |
| **TC-CRT-06** | Remove Item from Cart | Cart has 1 item | 1. Click trash icon on item<br>2. Confirm deletion | 1 Item in Cart | Item removed, Cart displays "Your shopping cart is empty", total = $0.00. | As expected. | **PASS** | **P1** |

---

## 💳 Module: Checkout & Order Placement

| TC ID | Title | Pre-Conditions | Test Steps | Test Data | Expected Result | Actual Result | Status | Priority |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :---: | :---: |
| **TC-CHK-01** | Checkout with Empty Shipping Fields | Items in cart | 1. Click 'Proceed to Checkout'<br>2. Leave Address blank<br>3. Click 'Continue' | Street: Empty, City: Empty | Red inline validation errors: "Shipping address is required". | As expected. | **PASS** | **P0** |
| **TC-CHK-02** | Checkout with Invalid Credit Card (Luhn check) | Valid shipping entered | 1. Select Credit Card<br>2. Enter invalid card number `4111111111111112`<br>3. Click Pay | Card: Invalid Luhn | Error message: "Invalid card number. Please check and retry." | Card accepted and charges simulated! | **FAIL** (BUG-03) | **P0** |
| **TC-CHK-03** | End-to-End Order Placement | Valid cart, valid card | 1. Fill shipping details<br>2. Enter valid test card<br>3. Click 'Place Order' | Standard Checkout | Order Confirmation page shown with unique Order ID `#ORD-XXXXX`, receipt email sent. | As expected. | **PASS** | **P0** |
| **TC-CHK-04** | Stock Decrement in Database after Order | Product stock = 10 | 1. Order 2 units of product<br>2. Complete order<br>3. Check database stock | Order Qty: 2 | Database stock reduces from 10 to 8. | As expected. | **PASS** | **P1** |
