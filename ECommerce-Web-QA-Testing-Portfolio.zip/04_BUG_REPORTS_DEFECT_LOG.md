# 🐞 Defect Log & Bug Reports — E-Commerce Web Application

**Author:** Sher Ali (QA Engineer)  
**Tool Standard:** Jira / Atlassian Defect Schema  

---

### 🔴 BUG-001: Price Sort "High to Low" Displays Free Items ($0.00) at the Top
* **Defect ID:** BUG-001
* **Severity:** Major (S2)
* **Priority:** High (P1)
* **Status:** Open
* **Module:** Product Catalog / Search Sorting
* **Environment:** Chrome 122.0.6261.95 (Windows 11)

#### Steps to Reproduce:
1. Navigate to the main `/products` catalog page.
2. Click on the **Sort By** dropdown menu.
3. Select **Price: High to Low**.
4. Observe the order of products returned on Page 1.

#### Expected Result:
Products should strictly order in descending numerical price (e.g., $1,200.00, $850.00, $350.00, ... $0.00).

#### Actual Result:
Promotional products with `$0.00` price appear at the very top of the list because NULL or zero values are being sorted as highest in the SQL query (`ORDER BY price DESC NULLS FIRST`).

---

### 🔴 BUG-002: Shopping Cart Allows Ordering Quantities Exceeding Warehouse Stock
* **Defect ID:** BUG-002
* **Severity:** Blocker / Critical (S1)
* **Priority:** Urgent (P0)
* **Status:** In Progress
* **Module:** Shopping Cart / Inventory
* **Environment:** Chrome 122, Firefox 123

#### Steps to Reproduce:
1. Open product page for item with low stock (e.g., Item ID 45 with only 3 units in stock).
2. Add 1 item to the cart.
3. Go to `/cart`.
4. In the quantity input field, manually type `25` and click **Update Cart**.
5. Click **Proceed to Checkout**.

#### Expected Result:
The cart should display an error: *"Only 3 units available in stock"* and automatically cap the quantity to 3.

#### Actual Result:
The cart accepts `25` without validation. The user can proceed to payment, creating backorders and inventory sync failure.

---

### 🔴 BUG-003: Checkout Accepts Invalid Credit Card Numbers Without Luhn Algorithm Check
* **Defect ID:** BUG-003
* **Severity:** Critical (S1)
* **Priority:** Urgent (P0)
* **Status:** Open
* **Module:** Payment / Checkout Gateway
* **Environment:** Cross-Browser

#### Steps to Reproduce:
1. Add any item to cart and proceed to checkout.
2. Fill in valid shipping address.
3. On payment screen, select **Credit Card**.
4. Enter dummy invalid card number `4111 1111 1111 1112` (fails Luhn checksum).
5. Enter any future date and 3 digits CVV.
6. Click **Pay & Place Order**.

#### Expected Result:
Frontend form validation should flag the card as invalid before sending request to payment gateway.

#### Actual Result:
Form submits without client-side validation, sending invalid card requests to the backend gateway, leading to 500 internal server errors.

---

### 🟡 BUG-004: Apply Coupon Button Double-Applies Discount on Fast Double-Click
* **Defect ID:** BUG-004
* **Severity:** Major (S2)
* **Priority:** Medium (P1)
* **Status:** Open
* **Module:** Cart / Promo Codes

#### Steps to Reproduce:
1. Add $100 item to cart.
2. Enter promo code `SAVE10` ($10 off).
3. Rapidly double-click the **Apply Coupon** button.

#### Expected Result:
Coupon should only apply once ($10 off, total = $90).

#### Actual Result:
Coupon code applies twice ($20 off, total = $80) due to lack of button debouncing.

---

### 🟢 BUG-005: Mobile Responsive Layout Overlaps 'Checkout' Button on Screen Width < 375px
* **Defect ID:** BUG-005
* **Severity:** Minor (S3)
* **Priority:** Low (P2)
* **Status:** Open
* **Module:** UI / Responsive Design
* **Environment:** iPhone SE (375x667 viewport)

#### Steps to Reproduce:
1. Open Cart page on mobile device or DevTools responsive view (375px width).
2. Scroll to bottom of cart.

#### Expected Result:
'Proceed to Checkout' button is fully visible with comfortable margins.

#### Actual Result:
Bottom sticky navigation bar partially overlaps the top half of the checkout button.
