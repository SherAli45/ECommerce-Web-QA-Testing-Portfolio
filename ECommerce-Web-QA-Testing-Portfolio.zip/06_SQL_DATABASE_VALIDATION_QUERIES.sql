-- ==============================================================================
-- E-COMMERCE DATABASE QA VALIDATION QUERIES
-- Author: Sher Ali (Software QA Engineer)
-- Description: Standard SQL queries used by QA to verify backend data
--              integrity after UI actions (Registration, Cart, Orders, Stock).
-- ==============================================================================

-- 1. VERIFY NEW USER REGISTRATION IN DATABASE
-- Run after completing registration on UI:
SELECT user_id, full_name, email, is_active, created_at
FROM users 
WHERE email = 'ali.test@example.com';


-- 2. VERIFY ORDER PLACEMENT & STATUS
-- Verify that order created via UI matches the displayed confirmation:
SELECT 
    o.order_id,
    o.order_number,
    o.user_id,
    o.total_amount,
    o.discount_amount,
    o.order_status,
    o.payment_status,
    o.created_at
FROM orders o
WHERE o.order_number = 'ORD-2026-9941';


-- 3. VERIFY ORDER LINE ITEMS & PRICING
-- Check that item prices in order_items match the catalog price:
SELECT 
    oi.order_id,
    p.product_name,
    oi.quantity,
    oi.unit_price,
    (oi.quantity * oi.unit_price) AS line_total
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
WHERE oi.order_id = 1042;


-- 4. VERIFY INVENTORY DEDUCTION AFTER ORDER (Regression Check)
-- Ensure warehouse stock decreased by exact purchased quantity:
SELECT 
    product_id,
    product_name,
    stock_quantity,
    CASE 
        WHEN stock_quantity < 0 THEN 'DEFECT: Negative Inventory'
        ELSE 'VALID'
    END AS inventory_status
FROM products
WHERE product_id IN (101, 105, 204);


-- 5. VERIFY APPLIED COUPON USAGE TRACKING
-- Ensure one-time coupon cannot be reused by the same user:
SELECT 
    c.coupon_code,
    c.discount_percent,
    cu.user_id,
    cu.order_id,
    cu.used_at
FROM coupons c
JOIN coupon_usages cu ON c.coupon_id = cu.coupon_id
WHERE c.coupon_code = 'SAVE20' AND cu.user_id = 45;
