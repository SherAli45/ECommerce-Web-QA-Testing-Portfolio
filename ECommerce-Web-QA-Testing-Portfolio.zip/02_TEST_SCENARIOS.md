# 🔍 Test Scenarios — E-Commerce Web Application

**Author:** Sher Ali (QA Engineer)  

---

## Module 1: User Authentication & Account
- **TS-AUTH-01:** Verify user can register with valid credentials and email verification.
- **TS-AUTH-02:** Verify system handles invalid registration inputs (weak password, duplicate email).
- **TS-AUTH-03:** Verify user can successfully log in with registered email and password.
- **TS-AUTH-04:** Verify login failure on incorrect password with proper error messaging and lockout after 5 attempts.
- **TS-AUTH-05:** Verify 'Forgot Password' password reset link delivery and password update flow.

---

## Module 2: Product Search & Browsing
- **TS-CAT-01:** Verify search by exact product name, partial name, and SKU code.
- **TS-CAT-02:** Verify product filtering by Category, Price Range, and Brand.
- **TS-CAT-03:** Verify product sorting by Price (Low to High, High to Low) and Customer Rating.
- **TS-CAT-04:** Verify product details page displays correct title, image gallery, price, and stock status.

---

## Module 3: Shopping Cart & Promotions
- **TS-CART-01:** Verify adding single and multiple products from catalog to shopping cart.
- **TS-CART-02:** Verify cart badge count updates accurately in real-time.
- **TS-CART-03:** Verify updating item quantities (including maximum stock boundary).
- **TS-CART-04:** Verify removing an item from the cart recalculates subtotal and taxes.
- **TS-CART-05:** Verify applying valid coupon code applies correct discount percentage.
- **TS-CART-06:** Verify applying expired or invalid coupon shows clear rejection message.

---

## Module 4: Checkout & Order Placement
- **TS-CHK-01:** Verify guest checkout vs. logged-in user checkout workflows.
- **TS-CHK-02:** Verify mandatory shipping address fields validation.
- **TS-CHK-03:** Verify shipping fee calculation based on selected shipping speed.
- **TS-CHK-04:** Verify payment method selection (Credit Card, PayPal, Cash on Delivery).
- **TS-CHK-05:** Verify order placement produces a unique Order ID and confirmation page.
- **TS-CHK-06:** Verify stock quantity in the database decreases immediately after order completion.
