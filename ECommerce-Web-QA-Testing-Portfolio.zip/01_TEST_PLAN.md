# 📋 Master Test Plan — E-Commerce Web Application

**Document Version:** 1.0.0  
**Prepared By:** Sher Ali (Software QA Engineer)  
**Application Under Test (AUT):** E-Commerce Web Platform (Desktop & Mobile Responsive)  

---

## 1. 🎯 Purpose & Scope

### 1.1 In-Scope:
* **User Authentication:** Registration, Login, Forgot Password, Logout.
* **Product Catalog:** Product search, category filters, sorting (Price, Popularity), product details view.
* **Shopping Cart:** Add to cart, update quantity, remove item, subtotal & tax calculation.
* **Discounts & Coupons:** Valid promo codes, expired promo codes, discount boundary calculations.
* **Checkout & Payment:** Shipping address validation, payment method selection, order review.
* **Order Confirmation:** Order receipt display, inventory stock decrement in database.

### 1.2 Out-of-Scope:
* Third-party payment gateway banking server internal failures.
* Load & Stress Performance testing under 100,000+ simultaneous users (scheduled for Phase 2).

---

## 2. 🧪 Test Strategy & Approach

* **Manual Functional Testing:** Verification of business logic, form validation, and error messages.
* **Boundary Value Analysis (BVA):** Testing cart quantities (0, 1, 99, 100, 101), discount percentage boundaries.
* **Negative Testing:** Special characters in address, invalid card numbers, empty required fields.
* **Cross-Browser Verification:** Tested on Chrome (v120+), Firefox (v121+), and Edge.
* **Backend Database Testing:** SQL queries to confirm data integrity between UI and DB.

---

## 3. 💻 Test Environment

* **Operating System:** Windows 11 / macOS Sonoma
* **Browsers:** Google Chrome, Mozilla Firefox, Microsoft Edge
* **Defect Tracking Tool:** Jira
* **Database Client:** pgAdmin / DBeaver / MySQL Workbench
* **Test Documentation:** Markdown & Excel Sheets

---

## 4. 🏁 Entry & Exit Criteria

### Entry Criteria:
- [x] Application deployed to QA Staging environment.
- [x] Test database populated with baseline products and test user accounts.
- [x] Test plan and test cases approved.

### Exit Criteria:
- 100% of P0 (Blocker) and P1 (Critical) test cases executed and passed.
- No open S1 (Critical) defects remaining.
- All identified defects documented in Defect Log with steps to reproduce and evidence.
